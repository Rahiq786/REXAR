CREATE TABLE Guest
	(GuestID 		 int(30) NOT NULL,
     FirstName 		 varchar(50),
	 LastName		 varchar(50),
     Phone			 varchar(15),
     Email			 varchar(100),
     StreetAddress	 varchar(100),
     ConfirmationNum int(6),
     RoomID		 	 int(10));
     
CREATE TABLE GuestLogin
	(LoginID	 	 int(30) NOT NULL,
	 LoginUsername	 varchar(30),
     LoginPassword   varchar(30),
	 GuestID		 int(30));
     
CREATE TABLE Reservation
	(ReservationID 	 int(10) NOT NULL,
     DateIn 		 date,
     DateOut		 date,
     TotalNights	 int(2),
     TotalGuests	 int(2),
     GuestID 		 int(30),
     EmployeeID      int(10));
     
CREATE TABLE Employee
	(EmployeeID 	 int(10) NOT NULL,
     EmployeeNum     int(15),
     FirstName  	 varchar(50),
     LastName		 varchar(50),
     EmployeePhone   varchar(15));

CREATE TABLE Room
	(RoomID  		 int(10) NOT NULL,
     RoomNumber 	 int(3),
     BedType  		 varchar(30),
     MaxCapacity     int(1),
     OccupyStatus    varchar(1),
     RoomRate        int(6));
          
CREATE TABLE Booked_Room
	(ReservationID 	 int(10) NOT NULL,
     RoomID			 int(10) NOT NULL,
     ConfirmationNum int(6));
     
CREATE TABLE Payment
	(PaymentID  	 int(15) NOT NULL,
     Price      	 decimal(10),
     PaymentDate     date,
     PaymentType     varchar(15),
     GuestID		 int(30));
     
ALTER TABLE Guest ADD CONSTRAINT
pk_guest PRIMARY KEY (GuestID);

ALTER TABLE GuestLogin ADD CONSTRAINT
pk_guestlogin PRIMARY KEY (LoginID);

ALTER TABLE Reservation ADD CONSTRAINT
pk_reservation PRIMARY KEY(ReservationID);

ALTER TABLE Employee ADD CONSTRAINT
pk_employee PRIMARY KEY (EmployeeID);

ALTER TABLE Room ADD CONSTRAINT
pk_room PRIMARY KEY (RoomID);

AlTER TABLE Booked_Room ADD CONSTRAINT
pk_roominfo PRIMARY KEY (ReservationID, RoomID);

ALTER TABLE Payment ADD CONSTRAINT
pk_payment PRIMARY KEY (PaymentID);

ALTER TABLE Guest ADD CONSTRAINT
fk_guest FOREIGN KEY (RoomID) REFERENCES
Room(RoomID);

ALTER TABLE GuestLogin ADD CONSTRAINT
fk_guestlogin FOREIGN KEY (GuestID) REFERENCES
Guest(GuestID);

ALTER TABLE Reservation ADD CONSTRAINT
fk_reservation FOREIGN KEY (GuestID) REFERENCES 
Guest(GuestID);

ALTER TABLE Reservation ADD CONSTRAINT
fk2_reservation FOREIGN KEY (EmployeeID) REFERENCES 
Employee(EmployeeID);

ALTER TABLE Payment ADD CONSTRAINT
fk_payment FOREIGN KEY (GuestID) REFERENCES
Guest(GuestID);

# Employee
INSERT INTO Employee VALUES (1, 123456789, 'Eric', 'Gong', '718-915-8289' );
INSERT INTO Employee VALUES (2, 213456789, 'Rahiq', 'Mohamed', '917-345-2586' );
INSERT INTO Employee VALUES (3, 312456789, 'Anh', 'Truong', '551-214-4166' );
INSERT INTO Employee VALUES (4, 412356789, 'Rachel', 'Chen', '917-969-2293' );
INSERT INTO Employee VALUES (5, 512346789, 'Guoxiong', 'Lin', '646-573-7339' );

# Room (RoomID, RoomNumber, BedType, MaxCapacity, OccupyStatus, RoomRate)
INSERT INTO Room VALUES (1, 233, 'Queen', 2, 'y', 1000);
INSERT INTO Room VALUES (2, 564, 'King', 2, 'n', 1200);
INSERT INTO Room VALUES (3, 123, 'Twin Beds', 4, 'n', 1800);
INSERT INTO Room VALUES (4, 799, 'Deluxe Queen', 2, 'n', 1500);
INSERT INTO Room VALUES (5, 346, 'Deluxe King', 2, 'n', 1500);

# Guest (GuestID, FirstName, LastName, Phone, Email, StreetAddress, ConfirmationNum, RoomID)
INSERT INTO Guest VALUES (1, 'Rudolph', 'Brown', '478-329-2495', 'rudolph_brown@gmail.com', '1399 Rosewood Lane, Manhattan NY, 10016', 357328, 1);

# GuestLogin (LoginID, LoginUsername, LoginPassword, GuestID)
INSERT INTO GuestLogin VALUES (1, 'rudolphbrown', 'password', 1);

# Reservation (ReservationID, DateIn, DateOut, TotalNights, TotalGuests, GuestID, EmployeeID)
INSERT INTO Reservation VALUES (1, '2019-05-08', '2019-05-09', 2, 1, 1, 1);

# Booked_Room (ReservationID, RoomID, ConfirmationNum)
INSERT INTO Booked_Room VALUES (1, 1, 357328);

# Payment (PaymentID, Price, PaymentDate, PaymentType, GuestID)
INSERT INTO Payment VALUES (1, 4000, '2019-05-01', 'Credit', 1);
